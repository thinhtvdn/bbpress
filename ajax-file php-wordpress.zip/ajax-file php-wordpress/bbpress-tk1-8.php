<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>jQuery Get Selected Option Value</title>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script>
function myFunction() {
	 idnd2=$("select.chonfcmb").children("option:selected").val()   // alert(idnd2)  
  var agrs = {
        url : "myfunc.php", 
        type : "post",  
        data : { 
               idnd : idnd2 
        },
        success : function (result){       
            $('#result').html(result);  
        }
    };
    $.ajax(agrs);
}
</script>
<?php
define('WP_USE_THEMES', false); require_once('wp-load.php' );  
getListUserPostCmb(); 

function getListUserPostCmb() { 
$args = array(	'role'   => 'Subscriber');
$user_query = new WP_User_Query( $args );
if ( ! empty( $user_query->get_results() ) ) { 
echo '<form id="frm1" action="" method="post">';
echo '<label> Chọn : </label>';
echo '<select class="chonfcmb">';
echo  '<option value="0">Người dùng</option>';
	foreach ( $user_query->get_results() as $user ) {
		$tendn=$user->user_login;   	$string=randposts($tendn); 
		if (!empty($string))  { 
		  	   $user_id=$user->ID;   $tenhienthi=$user->display_name;
			   echo '<option value="'.$tendn.'" >'.$tenhienthi.'</option>';
		}
	}
echo '</select>';
echo '<input type="button" onclick="myFunction()" value="Xem các bài viết">'; 
echo '</form>';
echo  '<div id="showdiv"></div> <p> Nội dung </p> ';
echo  ' <div id="result"> Nội dung ajax sẽ được load ở đây </div>';
}
} 
?>
</body>
</html>

