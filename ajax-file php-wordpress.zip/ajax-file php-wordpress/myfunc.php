<?php
define('WP_USE_THEMES', false); require_once('wp-load.php' );  // echo DB_HOST;
$string = '';
$tendangnhap=$_POST['idnd']; 
if (empty($tendangnhap))  return  $string;
$options = array(
 'post_type' => 'topic',
 'author_name' =>$tendangnhap,
);
$the_query = new WP_Query( $options ); 
if ( $the_query->have_posts() ) { 
  $string .= '<ul>';
   while ( $the_query->have_posts() ) {
          $the_query->the_post();
          $string .= '<li><a href="'. get_permalink() .'">'. get_the_title() .'</a>'. ' Ngày đăng '.get_the_date('d-m-Y H:i:s') .'</li>'; 
   }
   $string .= '</ul>';
   wp_reset_postdata();
}
echo $string;
?>