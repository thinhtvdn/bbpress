<?php 
ob_start();
define('WP_USE_THEMES', false); require_once('wp-load.php' );  
get_header();
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>jQuery Get Selected Option Value</title>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
<script>
function myFunction() {
    var agrs = {
                    type : "post",  
                    dataType : "json",  
                    url : '<?php echo admin_url('admin-ajax.php');?>', 
                    data : {
                        action: "thongbao",  
                        idnd : $("#chonfcmb").children("option:selected").val(),
                    },
                    context: this,
                    beforeSend: function(){ },
                    success: function(response) {
                        if(response.success) { $('#result').html(response.data);  }  
                        else {  $('#result').html("");  }  
                    },
					error:  function( jqXHR, textStatus, errorThrown ) {console.log( 'The following error occured: ' + textStatus, errorThrown );}
                };
 $.ajax(agrs);
}

</script>

<?php
$dem=0;
$args = array(	'role'   => 'Subscriber');
$user_query = new WP_User_Query( $args );
if ( ! empty( $user_query->get_results() ) ) { // User Loop
echo '<form id="frm1" action="" method="post">';
echo '<label for="chonfcmb"> Chọn  ';
echo '<select id="chonfcmb">';
echo  '<option value="0">Người dùng</option>';
	foreach ( $user_query->get_results() as $user ) {
		$tendn=$user->user_login;   	$string=randposts($tendn); 
		if (!empty($string))  { // nếu người dùng có bài viết
		       $dem=$dem+1;
		  	   $user_id=$user->ID;   $tenhienthi=$user->display_name;
			   echo '<option value="'.$tendn.'" >'.$tenhienthi.'</option>';
		}
	}
echo '</select>';
echo '</label>';
echo '<input type="button" onclick="myFunction();" value="Xem các bài viết">'; 
echo '</form>';
echo  '<div id="showdiv"></div> <p></p> ';
echo  ' <div id="result"></div>';
if ($dem==0)
{  header('Location: http://localhost/wordpress/dien-dan/');
exit;
ob_end_flush();
} 
}
?>
</body>
</html>
